package net.xclient.core.settings;

import java.util.function.Supplier;

/** Base class for a configurable module option, rendered as a widget in the ClickGUI. */
public abstract class Setting<T> {

    private final String name;
    protected T value;
    private Supplier<Boolean> visiblePredicate = () -> true;

    protected Setting(String name, T defaultValue) {
        this.name = name;
        this.value = defaultValue;
    }

    public String getName() {
        return name;
    }

    public T getValue() {
        return value;
    }

    public void setValue(T value) {
        this.value = value;
    }

    /** Hide this setting in the GUI unless the predicate is true (e.g. a slider only shown when a mode is active). */
    public Setting<T> visibleIf(Supplier<Boolean> predicate) {
        this.visiblePredicate = predicate;
        return this;
    }

    public boolean isVisible() {
        return visiblePredicate.get();
    }
}

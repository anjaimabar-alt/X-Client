package net.xclient.gui.hud;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.xclient.XClientMod;
import net.xclient.core.module.Module;
import net.xclient.gui.theme.XTheme;
import net.xclient.modules.hud.HudModule;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * Standalone editor for HUD widget placement AND size. Opened from the
 * ClickGUI's HUD tab ("Edit Layout"). Every enabled {@link HudModule} gets
 * an outlined bounding box:
 * <ul>
 *   <li>drag with the mouse to reposition (snaps to a 2px grid)</li>
 *   <li>scroll the mouse wheel over a widget (or a selected one) to resize it</li>
 *   <li>click a widget to select it, then use arrow keys to nudge it,
 *       {@code [ }/{@code ]} to shrink/grow it, or {@code R} to reset it</li>
 * </ul>
 * Selection persists after releasing the mouse so keyboard adjustments work
 * without holding a drag. Escape saves and exits (handled by {@link Screen}'s
 * default key handling, which still fires since unhandled keys fall through
 * to {@code super.keyPressed}).
 */
public class HudEditorScreen extends Screen {

    private static final float SCROLL_STEP = 0.05f;
    private static final float BRACKET_STEP = 0.05f;
    private static final float NUDGE_STEP = 1f;
    private static final float NUDGE_STEP_FAST = 8f;

    private HudModule dragging;
    private HudModule selected;
    private float dragOffsetX, dragOffsetY;

    public HudEditorScreen() {
        super(Text.literal("Edit HUD"));
    }

    private List<HudModule> enabledHuds() {
        List<HudModule> list = new ArrayList<>();
        for (Module module : XClientMod.getModuleManager().getModules()) {
            if (module instanceof HudModule hud && hud.isEnabled()) {
                list.add(hud);
            }
        }
        return list;
    }

    /** Topmost enabled HUD widget whose bounding box contains this point, or null. */
    private HudModule hudAt(double mouseX, double mouseY) {
        for (HudModule hud : enabledHuds()) {
            int w = Math.round(hud.getWidth() * hud.getScale());
            int h = Math.round(hud.getHeight() * hud.getScale());
            if (mouseX >= hud.getX() && mouseX <= hud.getX() + w && mouseY >= hud.getY() && mouseY <= hud.getY() + h) {
                return hud;
            }
        }
        return null;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0x60000000);
        ctx.drawCenteredTextWithShadow(textRenderer,
                "Drag to move - Scroll to resize - Arrows to nudge - R to reset - Escape to save",
                width / 2, 12, XTheme.TEXT_PRIMARY);

        HudModule hovered = hudAt(mouseX, mouseY);

        for (HudModule hud : enabledHuds()) {
            int w = Math.round(hud.getWidth() * hud.getScale());
            int h = Math.round(hud.getHeight() * hud.getScale());

            hud.render(ctx, width, height);

            boolean active = hud == dragging || hud == selected || hud == hovered;
            int outlineColor = hud == dragging ? XTheme.ACCENT
                    : hud == selected ? XTheme.ACCENT
                    : hud == hovered ? XTheme.TEXT_SECONDARY
                    : 0x50FFFFFF;
            int boxX = Math.round(hud.getX()) - 2;
            int boxY = Math.round(hud.getY()) - 2;
            ctx.drawStrokedRectangle(boxX, boxY, w + 4, h + 4, outlineColor);

            if (active) {
                String label = hud.getName() + "  " + Math.round(hud.getScale() * 100) + "%";
                int labelY = Math.max(2, boxY - 10);
                ctx.drawText(textRenderer, label, boxX, labelY, XTheme.TEXT_PRIMARY, true);
            }
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);

        HudModule hit = hudAt(mouseX, mouseY);
        if (hit != null) {
            dragging = hit;
            selected = hit;
            dragOffsetX = (float) (mouseX - hit.getX());
            dragOffsetY = (float) (mouseY - hit.getY());
            hit.setDragging(true);
            return true;
        }

        selected = null;
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (dragging != null) {
            float snappedX = Math.round((float) (mouseX - dragOffsetX) / 2f) * 2f;
            float snappedY = Math.round((float) (mouseY - dragOffsetY) / 2f) * 2f;
            dragging.setPosition(snappedX, snappedY);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (dragging != null) {
            dragging.setDragging(false);
            dragging = null;
            return true;
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        HudModule target = hudAt(mouseX, mouseY);
        if (target == null) target = selected;
        if (target != null) {
            target.adjustScale((float) (verticalAmount * SCROLL_STEP));
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (selected != null) {
            boolean fast = (modifiers & GLFW.GLFW_MOD_SHIFT) != 0;
            float step = fast ? NUDGE_STEP_FAST : NUDGE_STEP;
            switch (keyCode) {
                case GLFW.GLFW_KEY_LEFT -> {
                    selected.setPosition(selected.getX() - step, selected.getY());
                    return true;
                }
                case GLFW.GLFW_KEY_RIGHT -> {
                    selected.setPosition(selected.getX() + step, selected.getY());
                    return true;
                }
                case GLFW.GLFW_KEY_UP -> {
                    selected.setPosition(selected.getX(), selected.getY() - step);
                    return true;
                }
                case GLFW.GLFW_KEY_DOWN -> {
                    selected.setPosition(selected.getX(), selected.getY() + step);
                    return true;
                }
                case GLFW.GLFW_KEY_LEFT_BRACKET -> {
                    selected.adjustScale(-BRACKET_STEP);
                    return true;
                }
                case GLFW.GLFW_KEY_RIGHT_BRACKET -> {
                    selected.adjustScale(BRACKET_STEP);
                    return true;
                }
                case GLFW.GLFW_KEY_R -> {
                    selected.resetLayout();
                    return true;
                }
                default -> {
                    // fall through to super below
                }
            }
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void close() {
        XClientMod.getConfigManager().save(XClientMod.getModuleManager());
        super.close();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}

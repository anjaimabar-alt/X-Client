package net.xclient.gui.clickgui;

import net.xclient.core.module.Module;
import net.xclient.modules.hud.*;
import net.xclient.modules.misc.*;
import net.xclient.modules.movement.*;
import net.xclient.modules.optimization.*;
import net.xclient.modules.render.*;
import net.xclient.modules.utility.*;
import net.xclient.modules.world.*;

import java.util.Arrays;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Presentation data for the ClickGUI mod-menu cards: which filter tabs
 * (New / Hypixel / PvP) a module shows up under. The mod menu is text-only
 * (no per-module icon textures), so this only tracks tags now.
 * <p>
 * This is intentionally kept OUTSIDE {@link Module} and keyed by class
 * (not by display name) so that a typo here can never silently point at the
 * wrong module (a wrong class reference fails to compile; a wrong string
 * would not).
 */
public final class ModuleMeta {

    public enum Tag {
        NEW,
        HYPIXEL,
        PVP
    }

    private static final Map<Class<? extends Module>, Set<Tag>> TAGS = new HashMap<>();

    private ModuleMeta() {
    }

    private static void tags(Class<? extends Module> cls, Tag... tagList) {
        if (tagList.length == 0) return;
        TAGS.put(cls, EnumSet.copyOf(Arrays.asList(tagList)));
    }

    static {
        // ---------------- HUD ----------------
        tags(ArmorHUD.class, Tag.HYPIXEL);
        tags(CoordinatesModule.class, Tag.HYPIXEL);
        tags(CPSCounter.class, Tag.HYPIXEL, Tag.PVP);
        tags(FPSModule.class, Tag.HYPIXEL);
        tags(Keystrokes.class, Tag.HYPIXEL, Tag.PVP);
        tags(PingDisplay.class, Tag.HYPIXEL);
        tags(PotionHUD.class, Tag.HYPIXEL, Tag.PVP);
        tags(DayCounter.class, Tag.NEW);
        tags(ServerInfoHUD.class, Tag.HYPIXEL);
        tags(SprintModule.class, Tag.HYPIXEL);

        // ---------------- RENDER ----------------
        tags(Crosshair.class, Tag.HYPIXEL, Tag.PVP);
        tags(FullbrightModule.class, Tag.HYPIXEL);
        tags(NoHurtCam.class, Tag.PVP);
        tags(ScoreboardMod.class, Tag.HYPIXEL, Tag.PVP);
        tags(XClientIcon.class, Tag.NEW);

        // ---------------- OPTIMIZATION ----------------
        tags(SmartAnimations.class, Tag.NEW);
        tags(ShaderToggle.class, Tag.NEW);

        // ---------------- MOVEMENT ----------------
        tags(ZoomModule.class, Tag.HYPIXEL);
        tags(ParkourAssist.class, Tag.NEW);

        // ---------------- UTILITY ----------------
        tags(AutoGG.class, Tag.HYPIXEL, Tag.PVP);
        tags(ToolWarning.class, Tag.HYPIXEL);

        // ---------------- MISC ----------------
        tags(ChatFilter.class, Tag.NEW);
    }

    public static Set<Tag> tagsFor(Module module) {
        return TAGS.getOrDefault(module.getClass(), Set.of());
    }

    public static boolean isNew(Module module) {
        return tagsFor(module).contains(Tag.NEW);
    }

    public static boolean isHypixel(Module module) {
        return tagsFor(module).contains(Tag.HYPIXEL);
    }

    public static boolean isPvp(Module module) {
        return tagsFor(module).contains(Tag.PVP);
    }
}

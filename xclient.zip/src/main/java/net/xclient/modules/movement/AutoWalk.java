package net.xclient.modules.movement;

import net.xclient.core.module.Module;
import net.xclient.core.module.ModuleCategory;

/**
 * Simply holds "move forward" as if the key were physically held down -
 * equivalent to jamming a key with tape, nothing the server can't already
 * see as ordinary continuous forward input.
 */
public class AutoWalk extends Module {

    public AutoWalk() {
        super("Auto Walk", "Continuously walks forward without holding the key.", ModuleCategory.MOVEMENT);
    }
}

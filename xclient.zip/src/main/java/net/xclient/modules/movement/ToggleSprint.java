package net.xclient.modules.movement;

import net.xclient.core.module.Module;
import net.xclient.core.module.ModuleCategory;

/** Turns the sprint key into a toggle rather than hold-to-sprint - a vanilla accessibility pattern. */
public class ToggleSprint extends Module {

    public ToggleSprint() {
        super("Toggle Sprint", "Makes the sprint key a toggle instead of hold.", ModuleCategory.MOVEMENT);
    }
}

package net.xclient.modules.movement;

import net.xclient.core.module.Module;
import net.xclient.core.module.ModuleCategory;

/**
 * Re-routes movement key input to the player even while an inventory-type
 * screen is open (a convenience many servers explicitly allow) - it never
 * touches combat input, so it can't be used to hit while your GUI is open.
 */
public class InventoryMove extends Module {

    public InventoryMove() {
        super("Inventory Move", "Lets you walk while your inventory or a chest screen is open.",
                ModuleCategory.MOVEMENT);
    }
}

package net.xclient.modules.optimization;

import net.xclient.core.module.Module;
import net.xclient.core.module.ModuleCategory;

/**
 * One-click override that force-disables vanilla's expensive post-process
 * shaders (e.g. underwater/portal distortion) for extra headroom on weak
 * Android GPUs (Mali-G57, Adreno 505 class). Restores the previous state
 * on disable.
 */
public class ShaderToggle extends Module {

    private boolean previousState;

    public ShaderToggle() {
        super("Shader Toggle", "Force-disables expensive post-process shaders for extra performance.",
                ModuleCategory.OPTIMIZATION);
    }
}

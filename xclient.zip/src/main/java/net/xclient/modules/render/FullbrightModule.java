package net.xclient.modules.render;

import net.xclient.core.module.Module;
import net.xclient.core.module.ModuleCategory;

/**
 * Temporarily maxes the gamma option while enabled and restores the user's
 * previous value on disable. Equivalent to a vanilla options.txt edit -
 * doesn't touch lighting calculation, chunk data, or give x-ray-style info.
 */
public class FullbrightModule extends Module {

    private double previousGamma;

    public FullbrightModule() {
        super("Fullbright", "Raises brightness to maximum while enabled.", ModuleCategory.RENDER);
    }

    @Override
    protected void onEnable() {
        previousGamma = mc.options.getGamma().getValue();
        // Minecraft's gamma option only accepts values in [0.0, 1.0] - anything
        // outside that range fails the option's internal validation and is
        // silently ignored (no exception, the value just never changes), which
        // is why setting 100.0 here previously had no visible effect at all.
        mc.options.getGamma().setValue(1.0);
    }

    @Override
    protected void onDisable() {
        mc.options.getGamma().setValue(previousGamma);
    }
}

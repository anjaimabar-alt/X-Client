package net.xclient.modules.misc;

import net.xclient.core.module.Module;
import net.xclient.core.module.ModuleCategory;

import java.util.LinkedHashSet;
import java.util.Set;

/** Client-side chat mute list - hides messages from listed senders, same idea as blocking on a phone. */
public class IgnoreList extends Module {

    private final Set<String> ignored = new LinkedHashSet<>();

    public IgnoreList() {
        super("Ignore List", "Hides chat messages from players you've ignored.", ModuleCategory.MISC, true);
    }

    public void ignore(String name) {
        ignored.add(name.toLowerCase());
    }

    public void unignore(String name) {
        ignored.remove(name.toLowerCase());
    }

    public boolean isIgnored(String name) {
        return ignored.contains(name.toLowerCase());
    }
}

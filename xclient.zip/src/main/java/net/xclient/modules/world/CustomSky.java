package net.xclient.modules.world;

import net.xclient.core.module.Module;
import net.xclient.core.module.ModuleCategory;
import net.xclient.core.settings.ColorSetting;

/** Overrides the rendered sky gradient color client-side, purely cosmetic. */
public class CustomSky extends Module {

    private final ColorSetting topColor = register(new ColorSetting("Top Color", 0xFF1B0E10));
    private final ColorSetting bottomColor = register(new ColorSetting("Bottom Color", 0xFF3A1A1D));

    public CustomSky() {
        super("Custom Sky", "Overrides the sky gradient with custom colors.", ModuleCategory.WORLD);
    }

    public int getTopColor() {
        return topColor.getValue();
    }

    public int getBottomColor() {
        return bottomColor.getValue();
    }
}
